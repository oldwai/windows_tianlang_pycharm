#coding:utf-8
'''
@author:oldwai
'''

import subprocess
import uiautomation
from base import elements


class PublicMethod:

    # <editor-fold desc="start_process_fast 运行FAST">
    @staticmethod
    def start_process_fast():
        subprocess.Popen("C:\\Program Files (x86)\\MPRTimes\\ISLI FAST\\ISLI FAST.exe")
        root_window = uiautomation.PaneControl(searchDepth=1, ClassName='Qt5QWindow')
        uiautomation.WaitForExist(root_window, 1)
        root_window.ShowNormal()  # 激活显示
        root_window.SetWindowTopmost(True)  # 置顶显示
    # </editor-fold>

    @staticmethod
    def input(location,text):
        #找到元素位置点击，然后清除输入框，并输入账号密码
        location.Click()
        location.SendKeys('{Ctrl}a{Delete}')
        if text:
            location.SendKeys(text)

def login_isli_fast(username,password):
    #启动程序
    PublicMethod.start_process_fast()
    #实例化elements模块里的Login
    login_element= elements.Login_Window()

    # 输入信息函数【完成清空并发送账号，清空并发送密码】
    PublicMethod.input(login_element.username_edit,username)
    PublicMethod.input(login_element.password_edit,password)
    # 点击登录按钮
    login_element.login_button.Click()

def logout():
    logout_elment= elements.Login_Success_Window
    logout_elment.setting_options.Click()
    logout_elment.logout_option.Click()

def add_new_account(new_account,new_account_realname):
    #登录成功之后查看元素是否存在，实例化系统管理
    sysman_element= elements.System_manage()
    uiautomation.WaitForExist(sysman_element.chose_user_upgrade, 1)
    #切换到系统管理
    sysman_element.system_manage_window.Click()
    #点击用户管理
    sysman_element.user_manage_button.Click()
    #点击新增按钮
    sysman_element.add_new_button.Click()
    add_newuser_element= elements.AddNewuserWindow()
    PublicMethod.input(add_newuser_element.username_edit,new_account)
    PublicMethod.input(add_newuser_element.realname_edit,new_account_realname)
    add_newuser_element.role_choice.Click(ratioX=0.9)
    add_newuser_element.first_choice_list.Click(ratioX=0.1)
    add_newuser_element.role_choice.Click()
    add_newuser_element.enter_button.Click()


if __name__=="__main__":
    login_isli_fast("caolh","12345611")
    print (elements.Login_Window.account_error_message.Name)