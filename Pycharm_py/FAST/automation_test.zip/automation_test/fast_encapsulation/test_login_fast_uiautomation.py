#coding:utf-8
'''
@author:oldwai
'''
import unittest
from base import operation
from base import elements
import sys


class Login_test(unittest.TestCase):
    def setUp(self):
        # pass
        print(sys.path)
        #operation.PublicMethod.start_process_fast()

    # def testCase1(self):
    #     #验证正确的账号密码登录
    #     operation.login_isli_fast("caolh","123456")
    #     print (elements.Login_Window.account_error_message.Name)

    def testCase1(self):
        #验证正确用户名，错误密码
        operation.login_isli_fast("caolh","11111")
        login_prompt=elements.Login_Window.account_error_message
        self.assertEqual(login_prompt,"用户名或密码错误!",msg="登录失败，用户名或密码错误了")
        operation.logout()


    def tearDown(self):
        pass


if __name__=="__main__":
    unittest.main()



